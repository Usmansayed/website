<?php return array('dependencies' => array(), 'version' => '6190868494e43fdbfe85');
