<?php return array('dependencies' => array('bp-dynamic-widget-block', 'wp-i18n'), 'version' => 'a0bc0c217385be9f4f8c');
