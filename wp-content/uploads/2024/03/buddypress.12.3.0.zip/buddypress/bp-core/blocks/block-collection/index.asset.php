<?php return array('dependencies' => array('wp-blocks', 'wp-i18n'), 'version' => '7e6cee0f413b3cfda09e');
