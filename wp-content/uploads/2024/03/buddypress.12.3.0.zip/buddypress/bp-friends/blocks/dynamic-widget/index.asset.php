<?php return array('dependencies' => array('bp-dynamic-widget-block', 'wp-i18n'), 'version' => 'f27df4bc45c7c812d1a9');
