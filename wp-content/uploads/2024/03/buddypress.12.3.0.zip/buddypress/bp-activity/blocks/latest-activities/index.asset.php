<?php return array('dependencies' => array('bp-block-data', 'wp-block-editor', 'wp-blocks', 'wp-components', 'wp-element', 'wp-i18n', 'wp-server-side-render'), 'version' => '202a4b0b150c6b5de2a4');
