<?php return array('dependencies' => array('bp-dynamic-widget-block', 'wp-i18n'), 'version' => '706f6bc965fe81414f61');
